
# Choi,Jeongmin 20165974


import socket

import select

import sys

import os

import signal


 


 

VERSION = '2.0v'

sndCnt = 0

rcvCnt = 0


 

def prompt():

    sys.stdout.write("> ")

    sys.stdout.flush()


 

class Client(object):


 

    def __init__(self):

        self.host = "nsl2.cau.ac.kr"

        self.port = 25974

        self.sock = None

        self.NICKNAME = ''

        self.sndCnt = 0

        self.rcvCnt = 0


 

        if len(sys.argv) != 2:

            print('NICKNAME...!')

            os._exit(0)


 

        else:

            self.NICKNAME = sys.argv[1]


 

        if not self.NICKNAME.isalpha():

            print('ENGLISH ONLY')

            os._exit(0)


 

        if len(self.NICKNAME) > 64:

            print('maxlen : 64')

            os._exit(0)


 

        self.connect_to_server()


 

    def connect_to_server(self):

        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        self.sock.settimeout(2)


 

        ################# connect to remote host ################

        try:

            self.sock.connect((self.host, self.port))

            msg = self.NICKNAME

            self.sock.send(msg.encode())

            data = self.sock.recv(4096)

            print(data.decode())

        except:

            print('Unable to connect')

            sys.exit()


 

        prompt()

        self.wait_for_messages()


 

    def wait_for_messages(self):

        while 1:

            try:

                socket_list = [sys.stdin, self.sock]

                ################# Get the list sockets which are readable ################


 

                read_sockets, write_sockets, error_sockets = select.select(socket_list, [], [])


 

                for sock in read_sockets:

                    ################# incoming message from remote server ################

                    if sock == self.sock:

                        data = sock.recv(4096)


 

                        if not data.decode():

                            print('\nDisconnected from chat server')

                            sys.exit()

                        else:

                            ################# print data ################

                            sys.stdout.write(data.decode())

                            if data.decode().split(' ')[0].startswith('\r[') and data.decode().split(' ')[0].endswith(']'):

                                self.rcvCnt += 1

                            prompt()


 

                    ################# user entered a message ################


 

                    else:

                        msg = sys.stdin.readline()

                        if msg.strip() == '\\ver':

                            self.sock.send(('\\ver ' + VERSION).encode())

                        elif msg.strip() == '\\stats':

                            print('SEND : %d' % self.sndCnt)

                            print('RECV : %d' % self.rcvCnt)

                        else:

                            self.sock.send(msg.encode())

                            if str(msg).startswith('\\w '):

                                self.sndCnt += 1

                            elif not str(msg).startswith('\\'):

                               self.sndCnt += 1

                        prompt()

            except KeyboardInterrupt:

                self.sock.send(('\\quit').encode())

                print("bye~\n")

                self.sock.close()

                sys.exit()


 

if __name__ == '__main__':

    client = Client()
