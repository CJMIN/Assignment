// Choi,Jeongmin 20165974

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <pthread.h>
 
#define BUFLEN  2048  //Max buffer size
#define MAXUSER 8     //Max number of connected users
 
char sndBuffer[BUFLEN]; //send buffer
char rcvBuffer[BUFLEN]; //receive buffer

char buf[64 + 1];

void* writter(int);
void* reader(int);

struct sockaddr_in serverAddr;

char nickName[65];

char* serverIP = "165.194.35.202";  
int serverPort = 35974; 

int sockFd;  //Server connection socket

//declare variables 
//send and receive information for the stats command
int rcvCnt = 0;
int sndCnt = 0;

const char* ver = "HW4 CHAT CLIENT APPLICATION v3.0a"; //Version information of the client program

//ctrl+c Signal Handling Function
void sigHandler(int sig) {
        //Send connection termination message to server

	send(sockFd, "\\quit\n", BUFLEN, 0);
}


int main(int argc, char* argv[]) {
	pthread_t rThread, wThread;

	memset(nickName, 0x00, sizeof(nickName));

	if (argc != 2) {
		printf("give me nickname..\n");
		return 0;
	}
	else {
                // Filter nickname naming conventions
                // check max len
		if (strlen(argv[1]) > 64) {
			printf("max len 64");
			return 0;
		}

		strncpy(nickName, argv[1], 64);
 
                // check alphabet (ASCII code 65~90 : A~Z, 97~122 : a~z)
		for (int i = 0; i < strlen(nickName); i++) {
			if (!(nickName[i] >= 65 && nickName[i] <= 90) && !(nickName[i] >= 97 && nickName[i] <= 122))
			{
				printf("only alphabet\n");
				return 0;
			}
		}
	}

	sockFd = socket(AF_INET, SOCK_STREAM, 0); //create socket

	if (sockFd == -1) {
		printf("socket error\n");
		return 0;
	}

	serverAddr.sin_family = AF_INET;
	serverAddr.sin_port = htons(serverPort);
	serverAddr.sin_addr.s_addr = inet_addr(serverIP);

        // connect to server
	if (connect(sockFd, (struct sockaddr*) & serverAddr, sizeof(serverAddr)) == -1) {
		printf("connect error\n");
		return 0;
	}

        // Send user nickname
	send(sockFd, nickName, sizeof(nickName), 0);

	pthread_create(&wThread, NULL, (void*)writter, (void*)sockFd); //thread creation for writing
	pthread_create(&rThread, NULL, (void*)reader, (void*)sockFd); //thread creation for reading
	pthread_join(wThread, NULL);
	pthread_join(rThread, NULL);

	return 0;
}

void* reader(int sockFd) {
	int rcv = 0;
	signal(SIGINT, sigHandler); //Keyboard interrupt handler declaration

	while (1) {
		memset(rcvBuffer, 0x00, sizeof(rcvBuffer));

                //Receiving messages from the server
		rcv = recv(sockFd, rcvBuffer, BUFLEN - 1, 0);
                //Connection termination for graceful ending
		if (rcv == 0) {
			printf("\nConnection closed\n");
			exit(0);
		}
		else {
			printf("%s", rcvBuffer);
			if (strncmp(rcvBuffer, "[", 1) == 0)
				rcvCnt += 1;
		}
	}
}

void* writter(int sockFd) {

	while (1) {
		memset(sndBuffer, 0x00, sizeof(sndBuffer));
                //Input message from stdin (standard input)
		fgets(sndBuffer, BUFLEN - 1, stdin);

                //stats command processing (management of sending / receiving information by client program)
		if (strcmp(sndBuffer, "\\stats\n") == 0) {
			printf("send msg : %d\n", sndCnt);
			printf("recv msg : %d\n", rcvCnt);

			continue;
		}
 
                //When sending the ver command, it is transmitted as the version information of the client.
		if (strcmp(sndBuffer, "\\ver\n") == 0) {
			memset(sndBuffer, 0x00, sizeof(sndBuffer));
			sprintf(sndBuffer, "\\ver %s", ver);
		}
                //Sending messages to the server
		send(sockFd, sndBuffer, strlen(sndBuffer), 0);
                //Counts the number of transmissions, including the whisper command, not the command
		if (sndBuffer[0] != '\\' || strncmp(sndBuffer, "\\w ", 3) == 0)
			sndCnt += 1;
	}
}

