
# Choi,Jeongmin 20165974

import socket, select
import re

HOST = 'nsl2.cau.ac.kr'

PORT = 25974

VERSION = '1.2v'


class Server(object):
    ################# List to keep track of socket descriptors ################

    CONNECTION_LIST = []

    RECV_BUFFER = 4096  ################# Advisable to keep it as an exponent of 2 ################

    def __init__(self):

        self.usermap = {}

        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

        self.set_up_connections()

        self.client_connect()

    def set_up_connections(self):

        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self.server_socket.bind((HOST, PORT))

        self.server_socket.listen(8)  ################# max simultaneous connections. ################

        self.CONNECTION_LIST.append(self.server_socket)

    ################# Function to broadcast chat messages to all connected clients ################

    def broadcast_data(self, sock, message):

        ################# Do not send the message to master socket and the client who has send us the message ################

        for socket in self.CONNECTION_LIST:

            if socket != self.server_socket and socket != sock:

                try:

                    socket.send(message.encode())

                except:

                    socket.close()

                    self.CONNECTION_LIST.remove(socket)

    def send_data_to(self, sock, message):

        try:

            sock.send(message.encode())

        except:

            ################# broken socket connection may be, chat client pressed ctrl+c for example ################

            socket.close()

            self.CONNECTION_LIST.remove(sock)

    def client_connect(self):

        print("Chat server started on port " + str(PORT))

        while 1:

            read_sockets, write_sockets, error_sockets = select.select(self.CONNECTION_LIST, [], [])

            for sock in read_sockets:

                if sock == self.server_socket:

                    self.setup_connection()

                else:

                    ################# Data recieved from client, process it ################

                    try:

                        data = sock.recv(self.RECV_BUFFER)

                        if data.strip().decode():


                            ################# for quit ################
                            if data.strip().decode() == '\\quit':
                                self.broadcast_data(sock, "\r" + '[' + self.usermap[sock][0] + '] bye~\n')

                                print('<%s> disconnected. There are <%d> users now\n' % (
                                    self.usermap[sock][0], len(self.usermap) - 1))

                                self.broadcast_data(sock, "\r" + '<%s> disconnected. There are <%d> users now\n' % (
                                    self.usermap[sock][0], len(self.usermap) - 1))

                                del self.usermap[sock]

                                self.CONNECTION_LIST.remove(sock)

                                sock.close()

                                continue


                            ################# for list ################

                            if data.strip().decode() == '\\list':

                                for s in self.usermap.keys():
                                    self.send_data_to(sock, '\r<%s, %s, %s>\n' % (
                                        self.usermap[s][0], self.usermap[s][1][0], self.usermap[s][1][1]))


                            ################# for ver ################

                            if data.strip().decode().startswith('\\ver '):
                                print('\rSERVER VERSION : %s\nCLIENT VERSION : %s\n' % (
                                    VERSION, data.strip().decode().split(' ')[1]))

                                self.send_data_to(sock, '\rSERVER VERSION : %s\nCLIENT VERSION : %s\n' % (
                                    VERSION, data.strip().decode().split(' ')[1]))


                            ################# for change ################

                            if data.strip().decode().startswith('\\change '):

                                dupcheck = True

                                if not str(data.strip().decode().split(' ')[1]).isalpha():
                                    self.send_data_to(sock, '\rAlphabet only\n')
                                    dupcheck = False

                                if len(data.strip().decode().split(' ')[1]) > 64:
                                    self.send_data_to(sock, '\rMax len 64\n')
                                    dupcheck = False

                                for s in self.usermap.keys():

                                    if self.usermap[s][0] == data.strip().decode().split(' ')[1]:
                                        self.send_data_to(sock, '\rNickname [%s] already exists\n' %
                                                          data.strip().decode().split(' ')[1])
                                        dupcheck = False
                                        break

                                if dupcheck:
                                    addrtmp = self.usermap[sock][1]
                                    del self.usermap[sock]
                                    self.usermap[sock] = (data.strip().decode().split(' ')[1], addrtmp)


                            ################# for whisper ################

                            if str(data.strip().decode()).startswith('\\w '):

                                doneflag = False

                                for s in self.usermap.keys():

                                    if self.usermap[s][0] == data.strip().decode().split(' ')[1]:
                                        self.send_data_to(s, '\r' + '[' + self.usermap[sock][0] + '] (whisper) ' + str(
                                            data.strip().decode())[int(
                                            data.strip().decode().index(data.strip().decode().split(' ')[2])):] + '\n')

                                        doneflag = True

                                        break

                                if not doneflag:
                                    self.send_data_to(sock,
                                                      '\rUser [%s] not found\n' % data.strip().decode().split(' ')[1])


                            ################# for i hate professor ################

                            if data.strip().decode()[0] != '\\':
                                if re.search('i hate professor', data.strip().decode(), re.IGNORECASE):
                                    self.send_data_to(sock, '\rBANNED\n')
                                    self.broadcast_data(sock, "\r" + '[' + self.usermap[sock][0] + '] bye~\n')
                                    print('<%s> disconnected. There are <%d> users now\n' % (
                                        self.usermap[sock][0], len(self.usermap) - 1))
                                    self.broadcast_data(sock, "\r" + '<%s> disconnected. There are <%d> users now\n' % (
                                        self.usermap[sock][0], len(self.usermap) - 1))
                                    del self.usermap[sock]
                                    self.CONNECTION_LIST.remove(sock)
                                    sock.close()
                                    continue

                                self.broadcast_data(sock, "\r" + '[' + self.usermap[sock][0] + '] ' + data.decode())

                    except Exception as e:

                        print(e)

                        # self.broadcast_data(sock, "Client (%s, %s) is offline" % addr)

                        print("Client (%s, %s) is offline" % addr)

                        sock.close()

                        self.CONNECTION_LIST.remove(sock)

                        continue

        self.server_socket.close()

        ################# function  for connection ################

    def setup_connection(self):

        sockfd, addr = self.server_socket.accept()

        self.CONNECTION_LIST.append(sockfd)

        print("Client (%s %s) connected" % addr)

        username = sockfd.recv(self.RECV_BUFFER)

        ################# max connection check ################

        if len(self.usermap) >= 8:
            print("----FULL CONNECTION[%s]----" % username.strip().decode())

            self.send_data_to(sockfd, "full. cannot connect\n")

            sockfd.close()

            self.CONNECTION_LIST.remove(sockfd)

            return

        ################# dup check ################

        for uname, ad in self.usermap.values():

            if username.strip().decode() == uname:
                print("----DUP NICK[%s]----" % username.strip().decode())

                self.send_data_to(sockfd, "duplicate nickname. cannot connect\n")

                sockfd.close()

                self.CONNECTION_LIST.remove(sockfd)

                return

        self.usermap[sockfd] = (username.strip().decode(), addr)

        sockfd.send(('welcome <%s> to cau-cse chat room at <%s, %d>. You are <%d>th user\n' % (
            self.usermap[sockfd][0], HOST, PORT, len(self.usermap))).encode())

        print('<%s> connected. There are <%d> users now\n' % (self.usermap[sockfd][0], len(self.usermap)))

        self.broadcast_data(sockfd, "\r" + '<%s> connected. There are <%d> users now\n' % (
            self.usermap[sockfd][0], len(self.usermap)))


        ################# function for send data to all regested clents ################

    def send_data_to_all_regesterd_clents(self, sock, message):

        for local_soc, connection in self.usermap.iteritems():

            if local_soc != sock and connection.username is not None:
                self.send_data_to(local_soc, message)


class Connection(object):

    def __init__(self, address):
        self.address = address

        self.username = None


if __name__ == "__main__":
    server = Server()
