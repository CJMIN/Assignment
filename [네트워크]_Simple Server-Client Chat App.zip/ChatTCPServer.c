// Choi,Jeongmin 20165974

#include <stdio.h>

#include <stdlib.h>

#include <netinet/in.h>

#include <sys/socket.h>

#include <sys/types.h>

#include <arpa/inet.h>

#include <unistd.h>

#include <signal.h>
#include <netdb.h>

#include <pthread.h>

#include <string.h>



#define BUFLEN  2048

#define MAXUSER 8

int serverSock;
void sigHandler(int sig) {
	printf("\n\n===SERVER DOWN===\n");
	close(serverSock);
	exit(0);
}


typedef struct {

	int sockFd;              // "-9" means empty

	char uname[65];

	char ip[16];

	int port;

} st_User;



void* msgHandler(void* arg); //server instance for every connected client



int curUserCnt = 0; //number of currently connected clients



const char* ver = "HW4 CHAT SERVER APPLICATION v1.5a"; //version information of server ap



st_User u[MAXUSER]; // user info struct (max : 8)



char buffer[BUFLEN];

char uname[65];



// server socket info 



char* serverIP = "nsl2.cau.ac.kr";



int serverPort = 35974;


char serverName[256];
struct hostent *serverEnt;
/////////////////////////////////





int main(int argc, char* argv[]) {

	struct sockaddr_in serverAddr;

	struct sockaddr_in clientAddr;



	int serverSock, nFd, tt, client_addr_size;
        
	signal(SIGINT, sigHandler);
	pthread_t myThread;


	int dup = 1;

	client_addr_size = sizeof(clientAddr);



	for (int i = 0; i < MAXUSER; i++) {

		u[i].sockFd = -9;

	}



	serverAddr.sin_family = AF_INET; // set family to Internet 

	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);//htonl(INADDR_ANY); // set IP address 

	serverAddr.sin_port = htons(serverPort);



	printf("      CHAT SEVER STARTED      \n");
        printf("------------------------------");






	serverSock = socket(AF_INET, SOCK_STREAM, 0);



	if (serverSock == -1) {

		printf("socket error\n");

		return 0;

	}

	printf("\n=> socket created\n");



	if (setsockopt(serverSock, SOL_SOCKET, SO_REUSEADDR, &tt, sizeof(int)) == -1) {

		printf("setsockopt error\n");

		return 0;

	}

	printf("=>reusing port\n");





	if (bind(serverSock, (struct sockaddr*) & serverAddr, sizeof(struct sockaddr)) == -1) {

		printf("binding error\n");

		return 0;

	}

	printf("=>binding success\n\n");









	listen(serverSock, MAXUSER);

	printf("...listening...\n");









	while (1) {
                struct sockaddr_in myaddr;  // for connected server ip printing (welcome msg)
		nFd = accept(serverSock, (struct sockaddr*) & clientAddr, &client_addr_size);
                getsockname(nFd, (struct sockaddr*)& myaddr, &client_addr_size); // accepted sock information including connected server ip..


		dup = 1; //duplication check flag (0 means duplication -> exception)



		memset(uname, 0x00, sizeof(uname));

		memset(buffer, 0x00, sizeof(buffer));



		// receive nickname

		recv(nFd, uname, sizeof(uname), 0);


                // check the number of connected users (MAXUSER : 8)
		if (curUserCnt >= MAXUSER) {

			sprintf(buffer, "full. cannot connect");

			send(nFd, buffer, sizeof(buffer), 0);

			close(nFd);

			continue;

		}









		// dup check



		for (int i = 0; i < MAXUSER; i++) {
                        // comparing input nickname with nicknames already registed
			if (strncmp(uname, u[i].uname, 64) == 0) {

				sprintf(buffer, "duplicate nickname. cannot connect\n");

				send(nFd, buffer, sizeof(buffer), 0);

				close(nFd);

				dup = 0;

				break;

			}

		}


                // If redundancy exists, the following logic is skipped. and the main thread waits for accept
		if (dup == 0)



			continue;









		// user reg



		int j = 0;



		for (j = 0; j < MAXUSER; j++) {

			if (u[j].sockFd == -9) {              // -9 means empty
                                // Saving new user information to empty user list
				u[j].sockFd = nFd;

				strncpy(u[j].ip, inet_ntoa(clientAddr.sin_addr), 15);

				strncpy(u[j].uname, uname, 64);

				u[j].port = clientAddr.sin_port;

				curUserCnt += 1;

				break;

			}

		}









		// send welcome msg to user 



		memset(buffer, 0x00, sizeof(buffer));



		sprintf(buffer, "welcome <%s> to cau-cse chat room at <%s, %d>. You are <%d> th user\n", uname



			, inet_ntoa(myaddr.sin_addr)



			, serverPort



			, curUserCnt);



		send(nFd, buffer, sizeof(buffer), 0);









		// send connection info to all users (except cur thread's sock) 



		memset(buffer, 0x00, sizeof(buffer));



		sprintf(buffer, "<%s> connected. There are <%d> users now\n", uname



			, curUserCnt);



		printf(buffer);



		for (int i = 0; i < MAXUSER; i++) {



			if (u[i].sockFd != -9 && u[i].sockFd != nFd) {
                                //To all users except the newly connected user,


				send(u[i].sockFd, buffer, sizeof(buffer), 0);



			}



		}





		// create thread & detach 

		pthread_create(&myThread, NULL, msgHandler, (void*)& u[j]); //creating thread for every client connected

		pthread_detach(myThread);



	}

	close(serverSock);

}





void* msgHandler(void* parmUser) {

	st_User* user = parmUser;



	char rcvBuffer[BUFLEN];  //Receiving buffer

	char sndBuffer[BUFLEN];  //sending buffer




	memset(rcvBuffer, 0x00, sizeof(rcvBuffer));

	memset(sndBuffer, 0x00, sizeof(sndBuffer));



	while (1) {

		memset(rcvBuffer, 0x00, sizeof(rcvBuffer));

		memset(sndBuffer, 0x00, sizeof(sndBuffer));


                //Receive function to receive messages from users
		recv(user->sockFd, rcvBuffer, BUFLEN, 0);



		// quit

		if (strcmp(rcvBuffer, "\\quit\n") == 0) {

			close(user->sockFd); //socket close	

			user->sockFd = -9;  //Convert user list to -9 (empty)

			curUserCnt -= 1;  //Reduce the number of connected users

			printf("<%s> disconnected. There are <%d> users now\n", user->uname, curUserCnt);

			sprintf(sndBuffer, "[%s] bye~\n<%s> disconnected. There are <%d> users now\n", user->uname, user->uname, curUserCnt);



			for (int i = 0; i < MAXUSER; i++) {

				if (u[i].sockFd != -9)
                                        //Notify all connected users
					send(u[i].sockFd, sndBuffer, BUFLEN, 0);

			}


                        //Initialize user information
			memset(user->ip, 0x00, sizeof(user->ip));

			memset(user->uname, 0x00, sizeof(user->uname));

			user->port = 0;



			break;

		}



		// list

		else if (strcmp(rcvBuffer, "\\list\n") == 0) {

			for (int i = 0; i < MAXUSER; i++) {

				if (u[i].sockFd != -9)	//Attach user information to the transfer buffer
					sprintf(sndBuffer, "%s<%s,%s,%d>\n", sndBuffer, u[i].uname, u[i].ip, u[i].port);

			}

			send(user->sockFd, sndBuffer, BUFLEN, 0);

		}



		// ver

		else if (strncmp(rcvBuffer, "\\ver ", 5) == 0) {
                        //Combines version information of the user program that was delivered with the whisper command
			sprintf(sndBuffer, "%s\n------\n%s\n", ver, rcvBuffer + 5);

			send(user->sockFd, sndBuffer, BUFLEN, 0);

		}



		// change 

		else if (strncmp(rcvBuffer, "\\change ", 8) == 0) {
                        
			char* cut = strtok(rcvBuffer, " ");
                        
			cut = strtok(NULL, " "); //cut nickname after change command
			if (cut == NULL) continue; //If the nickname to replace does not come up, continue
			if (cut[strlen(cut) - 1] == '\n')

				cut[strlen(cut) - 1] = '\0'; //convert newline('\n') to null(\0)


                        //Check nickname rules
			if (strlen(cut) > 64) {

				send(user->sockFd, "max len 64\n", BUFLEN, 0);

				continue;

			}



			int cnFlag = 0;

			for (int i = 0; i < strlen(cut); i++) {

				if (!(cut[i] >= 65 && cut[i] <= 90) && !(cut[i] >= 97 && cut[i] <= 122))

				{

					send(user->sockFd, "only alphabet\n", BUFLEN, 0);

					cnFlag = 1;

					break;

				}

			}

			if (cnFlag)

				continue;



			cnFlag = 0;

			for (int i = 0; i < MAXUSER; i++) {

				if (strncmp(cut, u[i].uname, 64) == 0) {

					send(user->sockFd, "duplicate nickname\n", BUFLEN, 0);

					cnFlag = 1;

					break;

				}

			}

			if (cnFlag)

				continue;


                        //notify nickname change information to connected users

			sprintf(sndBuffer, "user %s -> %s done\n", user->uname, cut);

			for (int i = 0; i < MAXUSER; i++) {

				if (u[i].sockFd != -9)

					send(user->sockFd, sndBuffer, BUFLEN, 0);

			}

			strcpy(user->uname, cut);

		}



		else if (strncmp(rcvBuffer, "\\w ", 3) == 0) {

			char backup[BUFLEN];

			char toName[65];

			char* cut;

			char* toMsg;



			memset(backup, 0x00, sizeof(backup));

			memset(toName, 0x00, sizeof(toName));



			strcpy(backup, rcvBuffer); //Received original message backup (for use with strtok)



			cut = strtok(backup, " "); 

			cut = strtok(NULL, " "); //Name of user to receive

			if (cut == NULL)
				continue;

			strcpy(toName, cut);



			cut = strtok(NULL, " "); //Whisper contents
			if (cut == NULL)
				continue;

			toMsg = cut;



			sprintf(sndBuffer, "[%s] (wispher) %s", toName, strstr(rcvBuffer, toMsg));



			for (int i = 0; i < MAXUSER; i++) {

                                //Find the socket of the receiving user and pass it to the party only 
				if (strcmp(u[i].uname, toName) == 0) {

					send(u[i].sockFd, sndBuffer, BUFLEN, 0);

					break;

				}

			}

		}


                // Broadcast to all users if it is not a command
		else if (rcvBuffer[0] != '\\') {

			// message filtering (case ignore) 

			if (strcasestr(rcvBuffer, "i hate professor") != NULL) {

				sprintf(sndBuffer, "GET OUT!\n");

				send(user->sockFd, sndBuffer, BUFLEN, 0);



				close(user->sockFd);

				user->sockFd = -9;

				curUserCnt -= 1;



				printf("<%s> disconnected. There are <%d> users now\n", user->uname, curUserCnt);

				sprintf(sndBuffer, "[%s] bye~\n<%s> disconnected. There are <%d> users now\n", user->uname, user->uname, curUserCnt);


                                // Notify the connected users of disconnected users' disconnect information
				for (int i = 0; i < MAXUSER; i++) {

					if (u[i].sockFd != -9)

						send(u[i].sockFd, sndBuffer, BUFLEN, 0);

				}


				// Removed user information from the user list (initialized)
				memset(user->ip, 0x00, sizeof(user->ip));

				memset(user->uname, 0x00, sizeof(user->uname));

				user->port = 0;



				break;

			}





			// broadcasting message 

			sprintf(sndBuffer, "[%s] %s", user->uname, rcvBuffer);

			printf("%s", sndBuffer);









			for (int i = 0; i < MAXUSER; i++) {

				if (u[i].sockFd != -9 && u[i].sockFd != user->sockFd)

					send(u[i].sockFd, sndBuffer, BUFLEN, 0);

			}

		}

	}



	return 0;

}

