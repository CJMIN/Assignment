#include <stdio.h>

#include <unistd.h>

#include <pthread.h>

#include <stdlib.h>

int bank_money = 50;

void enter_region() {

	asm(

		".data\n"

		"lock:\n"

		".byte 0\n"

		".text\n"

		"_enter_region:\n"

		"movb $1, %al\n" // move 1 to AL

		"xchgb lock,%al\n"

		"cmp $0, %al\n"

		"jne _enter_region\n"

	);

}



void leave_region() {

	asm("movb $0, lock");

}



void critical_region_loan(char *p) {

	int d = rand() % 1000000;

	printf("\n\n <%s> 5 대출 \n\n", p);

	int register1 = 0;

	register1 = bank_money;

	usleep(rand() % 1000000);

	bank_money = register1 - 5;

	printf("\n\n현재 은행 잔고 :%d \n\n", bank_money);

	printf("%s sleep %d microsecond in critical section\n", p, d);

	usleep(d);

}

void critical_region_repay(char *p) {

	int d = rand() % 1000000;

	printf("\n\n <%s> 5 상환 \n\n", p);

	int register1 = 0;

	register1 = bank_money;

	usleep(rand() % 1000000);

	bank_money = register1 + 5;

	printf("\n\n현재 은행 잔고 :%d \n\n", bank_money);

	printf("%s sleep %d microsecond in critical section\n", p, d);

	usleep(d);

}



void noncritical_region(char *p) {

	int d = rand() % 1000000;

	printf("%s sleep %d microsecond in NON-critical section\n", p, d);

	usleep(d);

}




static void* f1(void* p) {

	int count = 0;

	while (5>count) {

		printf("\n\ncount : %d\n\n", count);

		puts("f1 wait for f2");

		//enter_region();

		printf("f1 start its critical section\n");

		critical_region_loan(p);

		printf("f1 end its critical section\n");

		//leave_region();

		noncritical_region(p);

		count++;

	}

	count = 0;

	while (5>count) {

		printf("\ncount : %d\n", count);

		puts("f1 wait for f2");

		//enter_region();

		printf("f1 start its critical section\n");

		critical_region_repay(p);

		printf("f1 end its critical section\n");

		//leave_region();

		noncritical_region(p);

		count++;

	}

	return NULL;

}

static void* f2(void* p) {

	int count = 0;

	while (5>count) {

		printf("\n\ncount : %d\n\n", count);

		puts("f2 wait for f1");

		//enter_region();

		printf("f2 start its critical section\n");

		critical_region_loan(p);

		printf("f2 end its critical section\n");

		//leave_region();

		noncritical_region(p);

		count++;

	}

	count = 0;

	while (5>count) {

		printf("\ncount : %d\n", count);

		puts("f2 wait for f1");

		//enter_region();

		printf("f2 start its critical section\n");

		critical_region_repay(p);

		printf("f2 end its critical section\n");

		//leave_region();

		noncritical_region(p);

		count++;

	}

	return NULL;

}




int main() {


	printf("\n초기 bank_money : %d\n", bank_money);

	int rc;



	pthread_t t1, t2;



	rc = pthread_create(&t1, NULL, f1, "f1");

	if (rc != 0) {

		fprintf(stderr, "pthread f1 failed\n");

		return EXIT_FAILURE;

	}



	rc = pthread_create(&t2, NULL, f2, "f2");

	if (rc != 0) {

		fprintf(stderr, "pthread f2 failed\n");

		return EXIT_FAILURE;

	}



	pthread_join(t1, NULL);

	pthread_join(t2, NULL);



	puts("All threads finished.");

	printf("\n예상 bank_money : 50\n");

	printf("\n실제 bank_money : %d\n", bank_money);

	if (bank_money == 50) {
		printf("\n Good~~ \n");
	}
	else {
		printf("\n Race - Condition 으로 인한 Critical - Section - Problem \n");
	}


	return 0;

}