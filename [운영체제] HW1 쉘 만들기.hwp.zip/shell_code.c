#include<sys/types.h>

 

#include<string.h>

 

#include<stdlib.h>

 

 

void type_prompt(){

 

 

        printf("\nJeongmin$ ");

 

 

}

 

 

int strcompare(const char *str1, const char *str2)

 

{

 

 

    for (; *str1 && (*str1 == *str2); str1++, str2++);

 

    return *str1 - *str2;

 

}

 

 

 

int read_command(char*input_str,char*input_str_pointer[]){

 

 

        char*result;

 

        int index = -1;

 

 

        result=strtok(input_str," ");

 

 

        while(result!=NULL){

 

 

                index++;

 

 

                input_str_pointer[index]=result;

 

 

                result=strtok(NULL," ");

 

 

        }

 

        input_str_pointer[index+1]='\0';

 

        return index + 1;

 

}

 

 

int main(){

 

 

        printf("start HW01 \n\n\n");

 

        char input_str[1000];

 

        char *input_str_pointer[1000];

 

        int status;

 

        int pid;

 

 

        while(1){

 

 

                int status;

 

                int num_len=0;

 

 

                type_prompt();

 

 

                gets(input_str);

		

		

 

                num_len = read_command(input_str,input_str_pointer);

 

	    int value= strcompare(input_str_pointer[0], "exit" );

	

	    if(value == 0){

			

	    	exit(1);

			

	    }

 

                pid = fork();

 

                if (pid<0){

 

                        exit(1);

 

                }

 

                else if (pid==0){

			

			if(execvp(input_str_pointer[0],input_str_pointer)<0){

				

				printf("\nerror\n");

				exit(1);

				

			}

 

                        execvp(input_str_pointer[0],input_str_pointer);

 

                }

 

                else{

 

                        wait(&status);

 

                }

 

        }

 

        return 0;

 

}