

int func(int a) {

    while(a==b){
       b=1;
    }

    if(1==b){
        a=g;
    }else{

        d=f;
    }

   if(num1!=num2){

      num1=num1/num2;
   }else{
      return 0;
   }



   return 0;
}