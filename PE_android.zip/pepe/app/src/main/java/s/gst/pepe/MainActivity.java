package s.gst.pepe;



import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;
import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;


import android.os.Build;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.mbms.StreamingServiceInfo;
import android.util.Log;
import android.view.View;
import android.os.AsyncTask;
import android.widget.Button;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;

import s.gst.pepe.R;


public class MainActivity extends AppCompatActivity {

    InetAddress ip = null;


    private final int REQUEST_BLUETOOTH_ENABLE = 100;
    private final int GET_GALLERY_IMAGE = 200;

    private View mLayout;  // Snackbar 사용하기 위해서는 View가 필요합니다.

    private TextView mConnectionStatus;
    private EditText mInputEditText;

    private ArrayAdapter<String> mConversationArrayAdapter;

    byte re= 0;

    int temp=0;

    int result=0;

    int result_temp=0;

    int count=0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //////////////////////////////////////////////////////////////////////////////


        mLayout = findViewById(R.id.layout_main);








        Button sendImageButton = (Button)findViewById(R.id.send_image_button);
        sendImageButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setData(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.setType("video/*");
                startActivityForResult(intent, GET_GALLERY_IMAGE);

            }
        });














        int writeExternalStoragePermission = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if ( writeExternalStoragePermission != PackageManager.PERMISSION_GRANTED){

            if (ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[0])) {


                Snackbar.make(mLayout, "이 앱을 실행하려면 카메라와 외부 저장소 접근 권한이 필요합니다.",
                        Snackbar.LENGTH_INDEFINITE).setAction("확인", new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                        ActivityCompat.requestPermissions( MainActivity.this, REQUIRED_PERMISSIONS,
                                PERMISSIONS_REQUEST_CODE);
                    }
                }).show();


            } else {

                ActivityCompat.requestPermissions( this, REQUIRED_PERMISSIONS,
                        PERMISSIONS_REQUEST_CODE);
            }

        }

        mConnectionStatus = (TextView)findViewById(R.id.connection_status_textview);
        mInputEditText = (EditText)findViewById(R.id.input_string_edittext);
        ListView mMessageListview = (ListView) findViewById(R.id.message_listview);

        mConversationArrayAdapter = new ArrayAdapter<>( this,
                android.R.layout.simple_list_item_1 );
        mMessageListview.setAdapter(mConversationArrayAdapter);


        //############################################################################


    }

    private static final int PERMISSIONS_REQUEST_CODE = 100;
    String[] REQUIRED_PERMISSIONS  = {Manifest.permission.WRITE_EXTERNAL_STORAGE};







    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grandResults) {

        if ( requestCode == PERMISSIONS_REQUEST_CODE && grandResults.length == REQUIRED_PERMISSIONS.length) {


            boolean check_result = true;



            for (int result : grandResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    check_result = false;
                    break;
                }
            }



            if ( check_result ) {
                ;
            }
            else {

                if (ActivityCompat.shouldShowRequestPermissionRationale(this, REQUIRED_PERMISSIONS[0])) {



                    Snackbar.make(mLayout, "퍼미션이 거부되었습니다. 앱을 다시 실행하여 퍼미션을 허용해주세요. ",
                            Snackbar.LENGTH_INDEFINITE).setAction("확인", new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {

                            finish();
                        }
                    }).show();

                }else {


                    Snackbar.make(mLayout, "퍼미션이 거부되었습니다. 설정(앱 정보)에서 퍼미션을 허용해야 합니다. ",
                            Snackbar.LENGTH_INDEFINITE).setAction("확인", new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {

                            finish();
                        }
                    }).show();
                }
            }

        }


    }










    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

//        if(requestCode == REQUEST_BLUETOOTH_ENABLE){
//            if (resultCode == RESULT_OK){
//                //BlueTooth is now Enabled
//                showPairedDevicesListDialog();
//            }
//            if(resultCode == RESULT_CANCELED){
//                showQuitDialog( "You need to enable bluetooth");
//            }
//        }else


        if ( requestCode == GET_GALLERY_IMAGE){
            String imgUri = getRealPathFromURI(data.getData());


//            SendPictureTask mythread=new SendPictureTask();
//
//            mythread.execute(imagePath);

            sendPicture(imgUri);

        }
    }


//    private class SendPictureTask extends AsyncTask<String, Void, Void>{
//
//        @Override
//        protected Void doInBackground(String... strings) {
//            System.out.println(strings+"첫번째*******************");
//
//            System.out.println(strings[0]+"두번째*******************");
//
//
//            sendPicture(strings[0]);
//
//            return null;
//        }
//
//        private void sendPicture(String imgUri) {
//
//            System.out.println("sendpicture 진입 1 ##########################");
//
//
//            String imagePath = imgUri;
//
//            System.out.println(imagePath+"세번쨰********************");
//
//            //Log.e(TAG, imagePath);
//
//            File file = new File(imagePath);
//            //sendMessage("Start"+file.length());
//
//            String split_code="/";
//
//            String[] arr = imagePath.split(split_code);
//
//
//            int idx=arr.length;
//
//            String file_name=arr[idx-1];
//
//            String file_path="";
//
//            System.out.println("sendpicture 진입 2 ##########################");
//
//            for(int i=0; i<arr.length-1; i++){
//                if(i==0){
//                    file_path=file_path+arr[i];
//                }else {
//                    file_path=file_path+"/"+arr[i];
//                }
//            }
//
//            System.out.println(file_name+"파일명%%%%%%%%%%%%%%%%%%%%%%%%");
//
//            System.out.println(file_path+"경로명$$$$$$$$$$$$$$$$$$$$$$$$");
//
//            try
//            {
//                System.out.println("이미지 전송 중");
//
//                System.out.println(imagePath);
//
//
//                try {
//
//
//
////         System.out.println("HostName : "+ip.getHostName() );
////
////         System.out.println("HostAddress : "+ip.getHostAddress() );
////
////         System.out.println("MyAddress : "+ip.getLocalHost().getHostAddress() );
////
////         System.out.println("HostAddress : "+ip);
//
//                    ip=InetAddress.getByName("192.168.0.6");
//                    System.out.println("sendpicture 진입 3 ##########################");
//
//                    Socket sock = new Socket(ip, 8080);// 오류발생
//
//                    System.out.println("sendpicture 진입 4 ##########################");
//
//                    try {
//
//                        System.out.println("데이터 찾는 중");
//
//                        File file2 = new File(file_path,file_name); //읽을 파일 경로 적어 주시면 됩니다.
//
//                        DataInputStream dis = new DataInputStream(new FileInputStream(file2));
//                        DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
//
//                        long fileSize = file2.length();
//                        byte[] buf = new byte[1024];
//
//                        long totalReadBytes = 0;
//                        int readBytes;
//                        System.out.println("데이터찾기 끝");
//
//                        while ((readBytes = dis.read(buf)) > 0) { //길이 정해주고 서버로 보냅니다.
//                            System.out.println("while");
//                            dos.write(buf, 0, readBytes);
//                            totalReadBytes += readBytes;}
//                        System.out.println("데이터보내기 끝 직전");
//                        dos.close();
//                        System.out.println("데이터끝");
//
//                    }catch(IOException e){
//
//                        System.out.println("IO*************");
//                        e.printStackTrace();
//                        System.out.println("sendpicture 진입 5 ##########################");
//                    }
//
//
//
//
//
//                }catch (Exception e) {
//                    // TODO: handle exception
//
//                    System.out.println("sendpicture 진입 6 ##########################");
//
//                    e.printStackTrace();
//                }
//
//
//
//
////            FileInputStream fis = new FileInputStream(imagePath);
////
////            byte[] buffer = new byte[4096];
////
////            int totalSize = fis.available();
////            int readSize = 0;
////            while ( (readSize=fis.read(buffer)) > 0) {
////
////                mConnectedTask.mOutputStream.write(buffer, 0, readSize);
////            }
////
////            fis.close();
////            ;
//
//
//            }
//            catch (Exception e)
//            {
//                e.printStackTrace();
//            }
//
//            mConversationArrayAdapter.insert("Me:  " + "Send Image" , 0);
//
//
//        }
//
//    }


    private void sendPicture(String imgUri) {
        String num="";
        FileInputStream fis=null;
        BufferedInputStream bis=null;
        DataInputStream dis2 = null;
        int f = 0;


        AsyncTask<String,Void,Void>asynctask=new AsyncTask<String, Void, Void>() {
            @Override
            protected Void doInBackground(String... strings) {

                BufferedReader in = null;
                DataInputStream dis = null;
                DataOutputStream dos = null;
                File file2 = null;
                Socket sock = null;

                FileOutputStream fos=null;
                BufferedOutputStream bos=null;
                DataOutputStream dos2 = null;

                String num="";







                System.out.println("sendpicture 진입 1 ##########################");

                String imagePath = strings[0];

                System.out.println(imagePath+"********************");

                //Log.e(TAG, imagePath);

                File file = new File(imagePath);
                //sendMessage("Start"+file.length());

                String split_code="\\\\";

                String[] arr = imagePath.split(split_code);

                System.out.println(arr.length);

                System.out.println(arr.length);
                int idx=arr.length;

                String file_name=arr[idx-1];

                String file_path="";

                System.out.println("sendpicture 진입 2 ##########################");

                for(int i=0; i<arr.length-1; i++){
                    if(i==0){
                        file_path=file_path+arr[i];
                    }else {
                        file_path=file_path+"\\"+arr[i];
                    }
                }

                try
                {
                    System.out.println("이미지 전송 중");

                    System.out.println(imagePath);


                    try {

                        ip=InetAddress.getByName("192.168.43.189");
                        System.out.println("sendpicture 진입 3 ##########################");

                        sock = new Socket(ip, 8080);// 오류발생

                        System.out.println("sendpicture 진입 4 ##########################");

                        System.out.println("데이터찾는중");

                        in = new BufferedReader(new InputStreamReader(sock.getInputStream()));

                        file2 = new File(file_path,file_name); //읽을 파일 경로 적어 주시면 됩니다.

                        dis = new DataInputStream(new FileInputStream(file2));

                        dos = new DataOutputStream(sock.getOutputStream());

                        long fileSize = file2.length();
                        byte[] buf = new byte[1024];

                        long totalReadBytes = 0;
                        int readBytes;
                        System.out.println("데이터찾기 끝");

                        while ((readBytes = dis.read(buf)) > 0) { //길이 정해주고 서버로 보냅니다.
                            System.out.println("while");
                            dos.write(buf, 0, readBytes);
                            totalReadBytes += readBytes;
                        }
                        System.out.println("데이터보내기 끝 직전");

//                        dis = new DataInputStream(sock.getInputStream());
//                        System.out.println("데이터끝1");
//                        num = dis.readUTF();
//
//                        System.out.println(num+"8888888888888888888888888888888888888888888888888888888888888888888888888888888");
//
////                        dos.close();
////                        sock.close();


                        dis = new DataInputStream(new BufferedInputStream(sock.getInputStream()));
                        System.out.println("데이터끝1");

                        re = dis.readByte();

                        count=(int)re;

                        count=count-48;


                        System.out.println("첫 숫자");
                        System.out.println(count);



                        while(true) {
                            count--;

                            re = dis.readByte();
                            temp=(int)re;

                            temp=temp-48;

                            result+=temp*Math.pow(10, count);
                            System.out.println(temp+"\n\n8888888888888888888888888888888888888888888888888888888888888888888888888888888");

                            if(count==0) {
                                System.out.println("탈출 결과 값 반환");
                                System.out.println(result);
                                result_temp=result;
                                result=0;
                                break;
                            }

                        }

//                        dos = new DataOutputStream(new FileOutputStream(file_path+"\\text.txt"));
//
//                        dos.writeInt(result);

//                        dis =new DataInputStream(new FileInputStream(file_path+"\\text.txt"));
//
//                        f=dis.readInt();
//                        System.out.println("******************************");
//                        System.out.println(f);
//                        System.out.println("******************************");


//                        mConversationArrayAdapter.insert("동영상 파일 사람 수:  " + result_temp , 0);

                        dos.close();



                        System.out.println("데이터끝2");


//                        BufferedReader in2 = new BufferedReader(new InputStreamReader(sock.getInputStream()));//추가
//                        String data = in2.readLine();
//
//                        System.out.println("sendpicture 진입 5 ##########################");
//
//                        System.out.println(data);

//                        System.out.println("sendpicture 진입 readLine 전 ##########################");
//
//                        String str2 = in.readLine();            //서버로부터 되돌아오는 데이터 읽어들임
//
//                        System.out.println("sendpicture 진입 readLine 후 ##########################");
//
//                        fos=new FileOutputStream(file_path+"num.txt");
//                        bos=new BufferedOutputStream(fos);
//                        dos2=new DataOutputStream(bos);
//
//                        dos2.writeUTF(str2);
//
//                        dos2.flush();
//                        dos2.close();
//
//                        System.out.println("서버로부터 되돌아온 메세지 : " + str2);
                        sock.close();


                    }catch (Exception e) {
                        // TODO: handle exception

                        System.out.println("sendpicture 진입 6 ##########################");

                        e.printStackTrace(); }

//                    try {
//
//                        System.out.println("sendpicture 진입 readLine 전 ##########################");
//
//                        String str2 = in.readLine();            //서버로부터 되돌아오는 데이터 읽어들임
//
//                        System.out.println("sendpicture 진입 readLine 후 ##########################");
//
//                        fos=new FileOutputStream(file_path+"num.txt");
//                        bos=new BufferedOutputStream(fos);
//                        dos2=new DataOutputStream(bos);
//
//                        dos2.writeUTF(str2);
//
//                        dos2.flush();
//                        dos2.close();
//
//                        System.out.println("서버로부터 되돌아온 메세지 : " + str2);
//                        sock.close();
//
//                    }catch(IOException e) {}



                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }




                return null;
            }
        };


        asynctask.execute(imgUri);


        String split_code="\\\\";

        String[] arr = imgUri.split(split_code);

        System.out.println(arr.length);

        System.out.println(arr.length);
        int idx=arr.length;

        String file_name=arr[idx-1];

        String file_path="";

        System.out.println("sendpicture 진입 2 ##########################");

        for(int i=0; i<arr.length-1; i++){
            if(i==0){
                file_path=file_path+arr[i];
            }else {
                file_path=file_path+"\\"+arr[i];
            }
        }

        mConversationArrayAdapter.insert("동영상 파일 사람 수:  " + result_temp , 0);
//        asynctask2.execute(imgUri);

//        DataInputStream dis = null;
//        try {
//            dis = new DataInputStream(new FileInputStream(file_path + "\\text.txt"));
//            f=dis.readInt();
//        }catch (Exception e){}
//
//        System.out.println("******************************");
//        System.out.println(f);
//        System.out.println("******************************");
//
//
//        mConversationArrayAdapter.insert("동영상 파일 사람 수:  " + f , 0);


    }


    private String getRealPathFromURI(Uri contentUri) {

        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        cursor.moveToFirst();
        int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);

        return cursor.getString(column_index);
    }

}

//class ServerReceiver extends Thread {
//    Socket socket;
//    DataInputStream in;
//    DataOutputStream out;
//
//    ServerReceiver(Socket socket) {
//        this.socket = socket;
//        try {
//            in  = new DataInputStream(socket.getInputStream());
//            out = new DataOutputStream(socket.getOutputStream());
//        } catch(IOException e) {}
//    }
//
//    public void run() {
//        String name = "";
//        try {
//            name = in.readUTF();
//
//        } catch(IOException e) {
//            // ignore
//        }
//    } // run
//} // ReceiverThread