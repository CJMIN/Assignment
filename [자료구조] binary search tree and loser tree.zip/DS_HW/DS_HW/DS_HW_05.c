#include <stdio.h>
#define numRow 5					/* 2�� ������ �ƴ� ������ ���� */
#define numCol 10 
#define CALLOC(p,n,s) \
    if (!(p = calloc(n,s))) { \
        fprintf(stderr, "Insufficient memory"); \
		exit(); \
    }

int value_num;
int count_max_num;

int *value = &value_num;
int *count_max = &count_max_num;


typedef struct TreeNode { /* ���� Ž�� Ʈ�� ����ü */

	int key;
	int count;
	int row_num;



	struct TreeNode *left, *right;

}TreeNode;



TreeNode *run_array[numRow] = { 0, }; //��Ʈ�� �������̹Ƿ� �����͹迭�̾���Ѵ�.

void inorder(TreeNode*root) {

	if (root) {

		inorder(root->left);


		if ((*count_max) < (root->count)) {

			*value = root->key;
			*count_max = root->count;
		}
		else if (*count_max == root->count) {
			if (*value < root->key)*value = root->key;
		}
		;

		inorder(root->right);
	}
}

void initial() {//��� ������ �ʱ�ȭ
	*value = 0;
	*count_max = 0;
}

TreeNode* create_loser_tree() { // loser Ʈ�� �迭�� ����
	int count_num = 0;
	int temp = numRow;
	while (temp != 0) {
		temp /= 2;
		count_num += 1;
	}
	temp = 1;
	while (count_num != 0) {

		temp = temp * 2;
		count_num = count_num - 1;

	}
	temp = temp * 2 - 1;


	TreeNode *losertree = (TreeNode*)malloc(sizeof(TreeNode)*(temp));

	for (int i = 0; i < temp; i++) {
		losertree[i].count = 0;
		losertree[i].key = 0;
		losertree[i].row_num = 0;

	}

	CALLOC(losertree, sizeof(TreeNode), temp)

		return losertree;
}





void insert_node(TreeNode**root, int key, int rowNum) {  /*  ���� Ž�� Ʈ�� ���� ���� �Լ� */

	TreeNode *p, *t;
	TreeNode *n;

	t = *root;
	p = NULL;

	while (t != NULL) {

		if (key == t->key) {
			t->count += 1;
			return;
		}
		p = t;
		if (key < p->key)t = p->left;
		else t = p->right;

	}

	n = (TreeNode*)malloc(sizeof(TreeNode));
	if (n == NULL)return;

	n->key = key;
	n->count = 1;
	n->row_num = rowNum;

	n->left = n->right = NULL;

	if (p != NULL) {
		if (key < p->key) {
			p->left = n;
		}
		else {
			p->right = n;
		}
	}
	else {
		*root = n;
	}

}

void create_run(int array[][numCol]) { // RUN ����

	for (int i = 0; i < numRow; i++) {


		for (int j = 0; j < numCol; j++) {

			insert_node(&run_array[i], array[i][j], i);
		}
	}
}

void delete_node(TreeNode**root, int key) { /* ���� Ž�� Ʈ�� ���� ���� �Լ� */
	TreeNode *p, *child, *succ, *succ_p, *t;

	p = NULL;
	t = *root;

	while (t != NULL && t->key != key) {
		p = t;
		t = (key < p->key) ? p->left : p->right;
	}

	if (t == NULL) {

		return;
	}

	if ((t->left == NULL) && (t->right == NULL)) {

		if (p != NULL) {
			if (p->left == t) {
				p->left = NULL;
			}
			else {
				p->right = NULL;
			}
		}
		else {
			*root = NULL;
		}

	}
	else if ((t->left == NULL) || (t->right == NULL)) {

		child = (t->left != NULL) ? t->left : t->right;

		if (p != NULL) {
			if (p->left == t) {
				p->left = child;
			}
			else {
				p->right = child;
			}

		}
		else {
			*root = child;
		}
	}
	else {
		succ_p = t;
		succ = t->right;

		while (succ->left != NULL) {
			succ_p = succ;
			succ = succ->left;
		}

		if (succ_p->left == succ) {
			succ_p->left = succ->right;
		}
		else {
			succ_p->right = succ->right;
		}
		t->key = succ->key;
		t = succ;
	}

	free(t);

}

int compare(TreeNode*loser_tree) {

	int count_num = 0;
	int temp = numRow;
	int n;
	while (temp != 0) {
		temp /= 2;
		count_num += 1;
	}
	temp = 1;
	while (count_num != 0) {

		temp = temp * 2;
		count_num = count_num - 1;

	}

	temp = temp - 1; // ������ ���� Ʈ���� ���� ó�� �ε��� ��

	n = temp;

	for (int i = numRow; i != 0; i = (i / 2)) {

		if (i != numRow)n /= 2; // 2�� n���� -1 �̹Ƿ�

		for (int j = n, m = 0; m < (n / 2) + (n % 2); j += 2, m++) {

			if ((loser_tree[j].count) < (loser_tree[j + 1].count)) {

				loser_tree[j / 2].count = loser_tree[j + 1].count;
				loser_tree[j / 2].key = loser_tree[j + 1].key;
				loser_tree[j / 2].row_num = loser_tree[j + 1].row_num;

			}
			else if ((loser_tree[j].count) > (loser_tree[j + 1].count)) {

				loser_tree[j / 2].count = loser_tree[j].count;
				loser_tree[j / 2].key = loser_tree[j].key;
				loser_tree[j / 2].row_num = loser_tree[j].row_num;

			}
			else {
				if ((loser_tree[j].key) > (loser_tree[j + 1].key)) {

					loser_tree[j / 2].count = loser_tree[j].count;
					loser_tree[j / 2].key = loser_tree[j].key;
					loser_tree[j / 2].row_num = loser_tree[j].row_num;

				}
				else if ((loser_tree[j].key) < (loser_tree[j + 1].key)) {

					loser_tree[j / 2].count = loser_tree[j + 1].count;
					loser_tree[j / 2].key = loser_tree[j + 1].key;
					loser_tree[j / 2].row_num = loser_tree[j + 1].row_num;

				}
				else {
					if ((loser_tree[j].row_num) > (loser_tree[j + 1].row_num)) {

						loser_tree[j / 2].count = loser_tree[j].count;
						loser_tree[j / 2].key = loser_tree[j].key;
						loser_tree[j / 2].row_num = loser_tree[j].row_num;

					}
					else if ((loser_tree[j].row_num) < (loser_tree[j + 1].row_num)) {

						loser_tree[j / 2].count = loser_tree[j + 1].count;
						loser_tree[j / 2].key = loser_tree[j + 1].key;
						loser_tree[j / 2].row_num = loser_tree[j + 1].row_num;

					}
				}
			}

		}

	}

	return &loser_tree[0];
}

void delete_losertree(TreeNode*losertree, int count_winner, int key_winner, int row_num_winner) {

	int count_num = 0;

	int index = 0;

	int temp = numRow;

	while (temp != 0) {
		temp /= 2;
		count_num += 1;
	}
	temp = 1;
	while (count_num != 0) {

		temp = temp * 2;
		count_num = count_num - 1;

	}
	temp = temp - 1 + numRow;

	for (int i = 0; i < temp - 1; i++) {


		if (losertree[i].count == count_winner && losertree[i].key == key_winner && losertree[i].row_num == row_num_winner) {

			losertree[i].count = 0;
			losertree[i].key = 0;
			losertree[i].row_num = 0;

		}

	}

}

void insert_losertree(TreeNode*losertree, int count_input, int key_input, int row_num_input) {

	int count_num = 0;

	int index = 0;

	int temp = numRow;

	while (temp != 0) {
		temp /= 2;
		count_num += 1;
	}
	temp = 1;
	while (count_num != 0) {

		temp = temp * 2;
		count_num = count_num - 1;
	}

	temp = temp - 1;


	TreeNode*pptr = &(losertree[temp + row_num_input]);

	pptr->count = count_input;

	pptr->key = key_input;

	pptr->row_num = row_num_input;

}

int matrix[numRow][numCol] = {		/* 2���� �迭�� ���� ���� */

	{ 1, 2, 3, 4, 5, 1, 2, 3, 4, 5 },
{ 11,12,13,11,12,13,11,12,13,20 },
{ 21,22,23,24,21,22,23,24,29,30 },
{ 31,32,33,34,35,31,32,33,34,35 },
{ 41,41,41,41,41,46,46,46,46,46 },

};


void main() {

	int count_winner = 0, key_winner = 0, row_num_winner = 0;

	int count_while = 0;

	TreeNode*losertree = create_loser_tree();//losertree ����

	TreeNode*ptr;

	create_run(matrix);

	for (int i = 0; i < numRow; i++) {

		inorder(run_array[i]);

		insert_losertree(losertree, *count_max, *value, i); // losertree���� �迭�� ù ��° �ּ� ���� ����Ǿ� �ִ�.

		delete_node(&run_array[i], *value);

		initial();

	}


	while (row_num_winner != -1) {

		if (count_while > 50) {
			break;
		}

		count_while += 1;


		ptr = compare(losertree); //�����ͺ����� �ּҰ��� ��ǲ���� ����

		count_winner = ptr->count;
		key_winner = ptr->key;
		row_num_winner = ptr->row_num;


		if (key_winner == 0 && count_winner == 0) {

			printf("\n~~~~~~~~~~~~��~~~~~~~~~~~~~~~~~~\n");

			break;
		}

		printf("\n(%d, %d, %d)\n", row_num_winner, key_winner, count_winner);

		delete_losertree(losertree, count_winner, key_winner, row_num_winner);



		inorder(run_array[row_num_winner]);

		insert_losertree(losertree, *count_max, *value, row_num_winner);

		delete_node(&run_array[row_num_winner], *value);

		initial();

	}


}